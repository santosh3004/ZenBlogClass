<?php
$servername = "localhost:3308";
$username = "root";
$password = "";
$dbname = "filemanagerproject";

$conn = new mysqli($servername,$username,$password,$dbname);
?>