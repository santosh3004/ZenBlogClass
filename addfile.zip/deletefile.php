<?php
require('config.php');
$id=$_GET['id'];

$q="SELECT filelink FROM filemanager WHERE id=$id";
$r=mysqli_query($conn,$q);
$row=$r->fetch_assoc();
$filename=$row["filelink"];
$filedel="uploads/".$filename;
unlink($filedel);



$query="DELETE FROM filemanager WHERE id=$id";
$result=mysqli_query($conn,$query);
if($result) {
 	/*while updating and just showing same page
 	reloading same page
 	echo "<meta http-equiv='refresh' content='0'>";*/
 echo header("Location: index.php?msg=dsuccess&data-show=trashed");
 }
 else
 {
echo header("Location: index.php?msg=derror");
 }

 ?>
